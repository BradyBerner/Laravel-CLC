<?php?>

<html>
	<body>
		<h1>Login Failure</h1>
		<a href="Login">Try Again</a>
	</body>
</html>