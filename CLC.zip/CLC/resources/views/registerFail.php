<?php?>

<html>
	<head>
	
	</head>
	
	<body>
		<h1>Registration Failed</h1>
		<a href="Register.php">Try Again</a>
	</body>
</html>