<?php
?>

<html>
	<head>
		<title>Login</title>
	</head>

	<body>
		<h1>Login</h1>
		
		<form action='loginHandler' method="POST">
			<input type="hidden" name="_token" value="<?php echo csrf_token()?>"/>
			Username: <input type="text" name="uname"><br>
			Password: <input type="password" name="pword"><br>
			<button type="submit">Login</button>
		</form>
		
		<a href="Register">Register Here</a>
	</body>
</html>