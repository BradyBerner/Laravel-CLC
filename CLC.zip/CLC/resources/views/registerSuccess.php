<?php?>

<html>
	<head>
	
	</head>
	
	<body>
		<h1>Registration Success</h1>
		<a href="Login">Login</a>
	</body>
</html>