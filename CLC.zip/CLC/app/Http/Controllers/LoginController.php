<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoginController extends Controller
{

    public function index(Request $request)
    {
        $username = $request->input('uname');
        $password = $request->input('pword');

        $connection = new \mysqli('localhost', 'root', 'root', 'laravelCLC');
        
        if ($connection) {
            $statement = $connection->prepare("SELECT * FROM `Users` WHERE `Username` = ? AND `Password` = ?");
        
            $statement->bind_param("ss", $username, $password);
            
            $statement->execute();
            
            $result = $statement->get_result();
        
            if ($result->num_rows != 0) {
                return view('loginSuccess');
            }
        }
        return view('loginFail');
    }
}
